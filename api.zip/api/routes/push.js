'use strict';

const express = require('express');
const web_push = require("web-push");

const { options } = require('../controllers');

const router = express.Router();


/*
 * Routes - Actions
 */
const vapidKeys = {
    publicKey: process.env.VAPID_PUBLIC_KEY,
    privateKey: process.env.VAPID_PRIVATE_KEY
};

const vapid_options = {
    vapidDetails: {
        subject: 'mailto:example_email@example.com',
        publicKey: vapidKeys.publicKey,
        privateKey: vapidKeys.privateKey,
    },
    TTL: 60,
};

// get client subscription config from db
const subscription = {
    endpoint: '',
    expirationTime: null,
    keys: {
        auth: '',
        p256dh: '',
    },
};

const payload = {
    notification: {
        title: 'Title',
        body: 'This is my body',
        // icon: 'assets/icons/icon-384x384.png',
        actions: [
            { action: 'bar', title: 'Focus last' },
            { action: 'baz', title: 'Navigate last' },
        ],
        data: {
            onActionClick: {
                default: { operation: 'openWindow' },
                bar: {
                    operation: 'focusLastFocusedOrOpen',
                    url: '/signin',
                },
                baz: {
                    operation: 'navigateLastFocusedOrOpen',
                    url: '/signin',
                },
            },
        },
    },
};

// -- should move in controllers

function send_public_key(req, res, next) {
    console.debug("Push (send public key)");

    try {
        res.status(200).json({ VAPID_PUBLIC_KEY: process.env.VAPID_PUBLIC_KEY });
    } catch (error) {
        console.error(error);
        res.status(404).json({ error });
    }
}

function register(req, res, next) {
    console.debug("Push (register)");

    try {
        // store subscription info
        res.status(201);
    } catch (error) {
        console.error(error);
        res.status(404).json({ error });
    }
}

function send_notification(req, res, next) {
    console.debug("Push (send notification)");
    setTimeout(notification, 10000);
}

function notification(req, res, next) {
    web_push
        .sendNotification(subscription, payload, vapid_options)
        .then(() => res.status(201))
        .catch(error => {
            console.error(error);
            res.status(500);
        }
        );
}

// -- Push Routes - /api/push

// -- 
router.get('/vapidPublicKey', send_public_key);
router.post('/register', register);
router.post('/notify', send_notification);


// -- options
router.options('/', options);

module.exports = router;
