'use strict';

const get_controller = require('./get');
const post_controller = require('./post');
const delete_controller = require('./delete');
const patch_controller = require('./patch');

module.exports = {
  get: get_controller,
  post: post_controller,
  delete: delete_controller,
  patch: patch_controller
};
